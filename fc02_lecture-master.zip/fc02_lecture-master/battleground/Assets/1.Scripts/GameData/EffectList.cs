using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public enum EffectList
{
	None = -1,
	
}